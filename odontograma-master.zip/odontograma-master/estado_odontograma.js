[
	{
		"id": "18",
		"tratamientos":[
			
		]
	}
]